﻿using Magenic.MaqsFramework.BaseSeleniumTest;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium;

namespace $safeprojectname$.Appium
{
    /// <summary>
    /// Page object
    /// </summary>
    public class ApplicationLogin
    {
        /// <summary>
        /// The user name input element 'By' finder
        /// </summary>
        private static By userNameLabel = By.XPath("//*/UIAStaticText[@value='loginUsername']");

        /// <summary>
        /// The password input element 'By' finder
        /// </summary>
        private static By passwordLabel = By.XPath("//*/UIAStaticText[@value='loginPassword']");

        /// <summary>
        /// Appium Mobile Driver
        /// </summary>
        private AppiumDriver<AppiumWebElement> appiumDriver;

        /// <summary>
        /// Initializes a new instance of the <see cref="ApplicationLogin" /> class.
        /// </summary>
        /// <param name="appiumDriver">The Appium Mobile driver</param>
        public ApplicationLogin(AppiumDriver<AppiumWebElement> appiumDriver)
        {
            this.appiumDriver = appiumDriver;
        }

        /// <summary>
        /// Get username text from label
        /// </summary>
        /// <returns>username text string</returns>
        public string GetLoggedInUsername()
        {
            return this.appiumDriver.WaitForVisibleElement(userNameLabel).Text;
        }

        /// <summary>
        /// Get password text from label
        /// </summary>
        /// /// <returns>password text string</returns>
        public string GetLoggedInPassword()
        {
            return this.appiumDriver.WaitForVisibleElement(passwordLabel).Text;
        }
    }
}
