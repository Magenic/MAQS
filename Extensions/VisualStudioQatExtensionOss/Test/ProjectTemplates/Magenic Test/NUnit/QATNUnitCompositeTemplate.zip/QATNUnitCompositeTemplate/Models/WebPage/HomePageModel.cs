﻿using Magenic.MaqsFramework.BaseSeleniumTest;
using Magenic.MaqsFramework.Utilities.Helper;
using NUnit.Framework;
using OpenQA.Selenium;

namespace $safeprojectname$
{
    /// <summary>
    /// Page object for the Automation page
    /// </summary>
    public class $safeitemname$
    {
         /// <summary>
        /// The page url
        /// </summary>
        private static string PageUrl = Config.GetValue("WebSiteBase") + "Static/Training3/HomePage.html";

        /// <summary>
        /// The username element 'By' finder
        /// </summary>
        private static By welcomeMessage = By.CssSelector("#WelcomeMessage");

        /// <summary>
        /// Selenium Web Driver
        /// </summary>
        private IWebDriver webDriver;

        /// <summary>
        /// Initializes a new instance of the <see cref="LoginPageModel" /> class.
        /// </summary>
        /// <param name="webDriver">The selenium web driver</param>
        public HomePageModel(IWebDriver webDriver)
        {
            this.webDriver = webDriver;
        }

        /// <summary>
        /// Verify we are on the Home page
        /// </summary>
        public bool AssertPageLoaded()
        {
            return this.webDriver.WaitUntilVisibleElement(welcomeMessage);
        }
    }
}

