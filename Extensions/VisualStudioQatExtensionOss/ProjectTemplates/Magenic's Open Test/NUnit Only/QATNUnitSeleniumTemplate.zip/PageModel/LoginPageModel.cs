﻿using Magenic.MaqsFramework.BaseSeleniumTest.Extensions;
using Magenic.MaqsFramework.Utilities.Helper;
using NUnit.Framework;
using OpenQA.Selenium;

namespace $safeprojectname$
{
    /// <summary>
    /// Page object for the Automation page
    /// </summary>
    public class $safeitemname$
    {
        /// <summary>
        /// The page url
        /// </summary>
        private static string PageUrl = Config.GetValue("WebSiteBase") + "Static/Training3/loginpage.html";

        /// <summary>
        /// The username element 'By' finder
        /// </summary>
        private static By userNameInput = By.CssSelector("#name");

        /// <summary>
        /// The password input element 'By' finder
        /// </summary>
        private static By passwordInput = By.CssSelector("#pw");

        /// <summary>
        /// The login button element 'By' finder
        /// </summary>
        private static By loginButton = By.CssSelector("#Login");

        /// <summary>
        /// The login error message element 'By' finder
        /// </summary>        
        private static By loginErrorMessage = By.CssSelector("#LoginError");

        /// <summary>
        /// Selenium Web Driver
        /// </summary>
        private IWebDriver webDriver;

        /// <summary>
        /// Initializes a new instance of the <see cref="LoginPageModel" /> class.
        /// </summary>
        /// <param name="webDriver">The selenium web driver</param>
        public LoginPageModel(IWebDriver webDriver)
        {
            this.webDriver = webDriver;
        }

        /// <summary>
        /// Open the login page
        /// </summary>
        public void OpenLoginPage()
        {
            this.webDriver.Navigate().GoToUrl(PageUrl);
            this.AssertPageLoaded();
        }

        /// <summary>
        /// Enter the use credentials
        /// </summary>
        /// <param name="userName">The user name</param>
        /// <param name="password">The user password</param>
        public void EnterCredentials(string userName, string password)
        {
            this.webDriver.Wait().ForVisibleElement(userNameInput).SendKeys(userName);
            this.webDriver.Wait().ForVisibleElement(passwordInput).SendKeys(password);
        }

        /// <summary>
        /// Enter the use credentials and log in - Navigation sample
        /// </summary>
        /// <param name="userName">The user name</param>
        /// <param name="password">The user password</param>
        public HomePageModel LoginWithValidCredentials(string userName, string password)
        {
            this.EnterCredentials(userName, password);
            this.webDriver.FindElement(loginButton).Click();
        
            HomePageModel newPage = new HomePageModel(this.webDriver);
            newPage.AssertPageLoaded();
            return newPage;
        }

        /// <summary>
        /// Enter the use credentials and try to log in - Verify login failed
        /// </summary>
        /// <param name="userName">The user name</param>
        /// <param name="password">The user password</param>
        public bool LoginWithInvalidCredentials(string userName, string password)
        {
            this.webDriver.Wait().ForVisibleElement(userNameInput).SendKeys(userName);
            this.webDriver.Wait().ForVisibleElement(passwordInput).SendKeys(password);
            this.webDriver.FindElement(loginButton).Click();
            return this.webDriver.Wait().UntilVisibleElement(loginErrorMessage);
        }

        /// <summary>
        /// Verify we are on the login page
        /// </summary>
        public void AssertPageLoaded()
        {
            Assert.IsTrue(
                this.webDriver.Wait().UntilVisibleElement(passwordInput),
                "The web page '{0}' is not loaded",
                PageUrl);
        }
    }
}

