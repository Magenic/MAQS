﻿using Magenic.MaqsFramework.BaseTest;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $rootnamespace$
{
    /// <summary>
    /// $safeitemname$ test class
    /// </summary>
    [TestClass]
    public class $safeitemname$ : BaseTest
    {
        /// <summary>
        /// Sample test
        /// </summary>
        [TestMethod]
        public void SampleTest()
        {
			this.Log.LogMessage("Sample Test");
			Assert.IsTrue(true, "true Is Not TRUE");
        }
    }
}
