﻿using Magenic.MaqsFramework.BaseDatabaseTest;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace $safeprojectname$
{
    /// <summary>
    /// $safeprojectname$ test class
    /// </summary>
    [TestClass]
    public class $safeitemname$ : BaseDatabaseTest
    {
		/// <summary>
        /// Sample test
        /// </summary>
        [TestMethod]
        public void SampleTest()
        {
            // TODO: Add test code
            // DataTable table = this.DatabaseWrapper.QueryAndGetDataTable("SELECT * FROM information_schema.tables");
            // Assert.AreEqual(table.Rows.Count, 10, "Expected 10 tables");
        }
    }
}