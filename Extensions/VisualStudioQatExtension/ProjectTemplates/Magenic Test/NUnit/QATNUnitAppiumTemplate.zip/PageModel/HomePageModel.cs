﻿using Magenic.MaqsFramework.BaseSeleniumTest;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium;

namespace $safeprojectname$
{
    /// <summary>
    /// Page object for $safeitemname$
    /// </summary>
    public class $safeitemname$
    {
		/// <summary>
        /// The user name input element 'By' finder
        /// </summary>
        private static By userNameLabel = By.XPath("//*/UIAStaticText[@value='loginUsername']");

        /// <summary>
        /// The password input element 'By' finder
        /// </summary>
        private static By passwordLabel = By.XPath("//*/UIAStaticText[@value='loginPassword']");

        /// <summary>
        /// Selenium Web Driver
        /// </summary>
        private AppiumDriver<AppiumWebElement> appiumDriver;

        /// <summary>
        /// Initializes a new instance of the <see cref="HomePageModel" /> class.
        /// </summary>
        /// <param name="appiumDriver">The selenium web driver</param>
        public HomePageModel(AppiumDriver<AppiumWebElement> appiumDriver)
        {
            this.appiumDriver = appiumDriver;
        }

        /// <summary>
        /// Get username text from label
        /// </summary>
        /// <returns>username text string</returns>
        public string GetLoggedInUsername()
        {
            return this.appiumDriver.WaitForVisibleElement(userNameLabel).Text;
        }

        /// <summary>
        /// Get password text from label
        /// </summary>
        /// /// <returns>password text string</returns>
        public string GetLoggedInPassword()
        {
            return this.appiumDriver.WaitForVisibleElement(passwordLabel).Text;
        }
    }
}