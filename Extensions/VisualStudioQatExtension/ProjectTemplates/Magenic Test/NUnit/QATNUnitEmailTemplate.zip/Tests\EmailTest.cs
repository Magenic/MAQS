﻿using Magenic.MaqsFramework.BaseEmailTest;
using NUnit.Framework;

namespace $safeprojectname$
{
    /// <summary>
    /// Simple email test class
    /// </summary>
    [TestFixture]
    public class $safeitemname$ : BaseEmailTest
    {
		/// <summary>
        /// Sample test
        /// </summary>
        [Test]
        public void SampleTest()
        {
            // TODO: Add test code
            // Assert.IsTrue(this.EmailWrapper.CanAccessEmailAccount(), "Could not access account");
        }
    }
}