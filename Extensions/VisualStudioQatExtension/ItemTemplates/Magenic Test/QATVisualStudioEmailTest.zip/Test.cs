﻿using Magenic.MaqsFramework.BaseEmailTest;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $rootnamespace$
{
    /// <summary>
    /// $safeitemname$ test class
    /// </summary>
    [TestClass]
    public class $safeitemname$ : BaseEmailTest
    {
        /// <summary>
        /// Sample test
        /// </summary>
        [TestMethod]
        public void SampleTest()
        {
            // TODO: Add test code
            // Assert.IsTrue(this.EmailWrapper.CanAccessEmailAccount(), "Could not access account");
        }
    }
}
