﻿using Magenic.MaqsFramework.BaseWebServiceTest;
using NUnit.Framework;

// TODO: Add reference to object model
// using Model;

namespace $rootnamespace$
{
    /// <summary>
    /// $safeitemname$ test class
    /// </summary>
    [TestFixture]
    public class $safeitemname$ : BaseWebServiceTest
    {
        /// <summary>
        /// Sample test
        /// </summary>
        [Test]
        public void SampleTest()
        {
            // TODO: Add test code
            //ITEM result = this.WebServiceWrapper.Get<ITEM>("/api/GetITEM/1", "application/xml", false);
        }
    }
}
