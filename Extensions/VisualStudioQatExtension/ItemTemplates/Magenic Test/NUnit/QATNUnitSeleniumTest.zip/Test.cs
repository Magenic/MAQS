﻿using Magenic.MaqsFramework.BaseSeleniumTest;
using NUnit.Framework;

// TODO: Add reference to object model
// using PageModel;

namespace $rootnamespace$
{
    /// <summary>
    /// $safeitemname$ test class
    /// </summary>
    [TestFixture]
    public class $safeitemname$ : BaseSeleniumTest
    {
        /// <summary>
        /// Sample test
        /// </summary>
        [Test]
        public void SampleTest()
        {
            // TODO: Add test code
            //PageModel page = new PageModel(this.WebDriver);
            //page.OpenPage();
        }
    }
}
